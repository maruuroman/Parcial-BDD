import { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from './Components/Home';
import RecetaDetail from "./Components/RecetaDetail";
import AddReceta from "./Components/AddReceta";
import EditReceta from "./Components/EditReceta";

const App = () => {
  const [recetas, setRecetas] = useState([]);
  const [selectedReceta, setSelectedReceta] = useState(null);


    // GET all receta
    useEffect(() => {
      const fetchRecetas = async () => {
        try {
          const response = await fetch("http://localhost:3000/dishes");
          const data = await response.json();
          setRecetas(data);
        } catch (error) {
          console.error("Error fetching recetas:", error);
        }
      };
  
      fetchRecetas();
    }, []);
  
    // GEt receta by ID
    const fetchRecetaById = async (id) => {
      try {
        const response = await fetch(`http://localhost:3000/dishes/${id}`);
        const data = await response.json();
        setSelectedReceta(data[0]); 
      } catch (error) {
        console.error("Error fetching receta by ID:", error);
      }
    };
  
    // DELETE a receta by ID
    const deleteRecetaById = async (id) => {
      try {
        const response = await fetch(`http://localhost:3000/dishes/${id}`, {
          method: 'DELETE',
        });
        if (response.ok) {
          setRecetas((prevRecetas) => prevRecetas.filter((receta) => receta.id !== id));
        
        } else {
          console.error('Error deleting receta');
        }
      } catch (error) {
        console.error("Error deleting receta:", error);
      }
    };
  
    // POST a new receta
    const addReceta = async (newReceta) => {
      try {
        const response = await fetch("http://localhost:3000/dishes", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newReceta),
        });
        const data = await response.json();
        const reply = await fetch("http://localhost:3000/dishes");
        const payload = await reply.json();
        console.log(payload)
          setRecetas(payload);
        //setRecetas(data);
      } catch (error) {
        console.error("Error adding new receta:", error);
      }
    };
  
    // PUT (update) a receta by ID
    const updateRecetaById = async (id, updatedReceta) => {
      try {
        const response = await fetch(`http://localhost:3000/dishes/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updatedReceta),
        });
        if (response.ok) {
          const data = await response.json();
          setRecetas(data); 
        } else {
          console.error('Error updating receta');
        }
      } catch (error) {
        console.error("Error updating receta:", error);
      }
    };


  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home recetas={recetas} deleteRecetaById={deleteRecetaById} />} />
        <Route path="/dishes/:id" element={<RecetaDetail recetas={recetas} fetchRecetaById={fetchRecetaById} selectedReceta={selectedReceta}  />} />
        <Route path="/agregar”" element={<AddReceta onAddReceta={addReceta} />} />
        <Route path="/details/:recetaId" element={<EditReceta recetas={recetas} onUpdateReceta={updateRecetaById} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App
