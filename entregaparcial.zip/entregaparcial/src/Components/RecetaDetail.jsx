import { useParams, useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./RecetaDetail.module.css";
import { Link } from "react-router-dom";

const RecetaDetail = ({ recetas }) => {
    const { id } = useParams();
    const navigate = useNavigate();
  
    const receta = recetas?.find((receta) => receta.id === id);
  
    if (!receta) {
      return <p>La receta que buscas no esta cargada.</p>;
    }
  
    return (
      <div className={styles.recetaDetailsContainer}>
        <button className={styles.backButton} onClick={() => navigate("/")}>
          Atrás
        </button>
        <h2>{receta.name}</h2>
        <p>Descripción: {receta.description}</p>
        <p>Preparación: {receta.preparation}</p>
        <p>Categorías: {receta.type}</p>
  
        <Link to={`/details/${receta.id}`}>
        <button className={styles.editButton}>Editar receta</button>
      </Link>
      </div>
    ); 
  };
  
  // Definir PropTypes para validar las props del componente
  RecetaDetail.propTypes = {
    recetas: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired,
        receta: PropTypes.string.isRequired,
        description: PropTypes.string,
        preparacion: PropTypes.string,
        categories: PropTypes.string,
      })
    ).isRequired,
  };
  
export default RecetaDetail;
