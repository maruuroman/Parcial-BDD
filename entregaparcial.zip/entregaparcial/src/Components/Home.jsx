import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import RecipiesList from "./RecipiesList";
import styles from "./Home.module.css";


const Home = ({ recetas, deleteRecetaById }) => {
    return (
      <div className={styles.homeContainer}>
        <h2>Recetas</h2>
        <Link to="/agregar”">
          <button className={styles.addButton}>Agregar receta</button>
        </Link>
        
        <RecipiesList recetas={recetas} deleteRecetaById={deleteRecetaById} />
      </div>
    );
  };
  
  Home.propTypes = {
    recetas: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired,
        receta: PropTypes.string.isRequired,
        description: PropTypes.string,
        preparacion: PropTypes.string,
        categories: PropTypes.string,
      })
    ).isRequired,
    deleteRecetaById: PropTypes.func.isRequired,
  };
  
  export default Home;