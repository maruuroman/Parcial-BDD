import styles from "./RecipiesList.module.css";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";

const RecipiesList = ({ recetas, deleteRecetaById }) => {
  const navigate = useNavigate();

  return (
    <div className={styles.recetasList}>
      {recetas.map((receta) => (
        <div key={receta.id} className={styles.recetaBox}>
          <h3>{receta.name}</h3>
          <p>{receta.type}</p>
          <button
            className={styles.detailsButton}
            onClick={() => navigate(`/dishes/${receta.id}`)}>
            Detalles
          </button>
          <button className={styles.deleteButton}
          onClick={() => deleteRecetaById(receta.id)}
          >Borrar</button>
        </div>
      ))}
    </div>
  );
};

RecipiesList.propTypes = {
  recetas: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      receta: PropTypes.string.isRequired,
      description: PropTypes.string,
      preparacion: PropTypes.string,
      categories: PropTypes.string,
    })
  ).isRequired,
  deleteRecetaById: PropTypes.func.isRequired,
};

export default RecipiesList;
