import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import PropTypes from "prop-types";
import styles from "./EditReceta.module.css"; 

const EditReceta = ({ recetas, onUpdateReceta }) => {
  const { recetaId } = useParams(); 
  const navigate = useNavigate();
  const recetaToEdit = recetas.find(receta => receta.id === recetaId);

  const [name, setReceta] = useState(recetaToEdit?.name || "");
  const [description, setDescription] = useState(recetaToEdit?.description || "");
  const [preparation, setPreparacion] = useState(recetaToEdit?.preparation || "");
  const [type, setCategories] = useState(recetaToEdit?.type || "");

  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedReceta = { name, description, preparation, type };
    onUpdateReceta(recetaId, updatedReceta);
    navigate("/"); 
  };

  return (
    <div className={styles.editRecetaContainer}>
      <button className={styles.backButton} onClick={() => navigate("/")}>
        Atrás
      </button>
      <h2>Editar receta</h2>
      <form onSubmit={handleSubmit}>
        <div className={styles.formGroup}>
          <label>Receta:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setReceta(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Descripción:</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Preparación:</label>
          <input
            type="text"
            value={preparation}
            onChange={(e) => setPreparacion(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Categorías:</label>
          <input
            type="text"
            value={type}
            onChange={(e) => setCategories(e.target.value)}
            required
          />
        </div>
        <button type="submit" className={styles.submitButton}>Guardar cambios</button>
      </form>
    </div>
  );
};

// Validación de props
EditReceta.propTypes = {
  recetas: PropTypes.array.isRequired,
  onUpdateReceta: PropTypes.func.isRequired,
};

export default EditReceta;
