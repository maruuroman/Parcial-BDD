import { useState } from 'react';
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types"; 
import styles from "./AddReceta.module.css"; 

const AddReceta = ({ onAddReceta }) => {
    const [name, setReceta] = useState("");
    const [description, setDescription] = useState("");
    const [preparation, setPreparacion] = useState("");
    const [type, setCategories] = useState("");
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const newReceta = { name, description, preparation, type };
        onAddReceta(newReceta);
        navigate("/"); 
      };

      return (
        <div className={styles.addRecetaContainer}>
          <button className={styles.backButton} onClick={() => navigate("/")}>
            Atrás
          </button>
          <h2>Agregar nueva receta</h2>
          <form onSubmit={handleSubmit}>
            <div className={styles.formGroup}>
              <label>Receta:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setReceta(e.target.value)}
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label>Descripción:</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label>Preparación:</label>
              <input
                type="text"
                value={preparation}
                onChange={(e) => setPreparacion(e.target.value)}
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label>Categorías:</label>
              <input
                type="text"
                value={type}
                onChange={(e) => setCategories(e.target.value)}
                required
              />
            </div>
            <button type="submit" className={styles.submitButton}>Agregar receta</button>
          </form>
        </div>
      );
    };
    
 
    AddReceta.propTypes = {
        onAddReceta: PropTypes.func.isRequired,
    };

export default AddReceta;